/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class Array {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int n=0;
        int[] arr = {2, 7, 6, 1, 9};
        for (int i = 0; i < arr.length; i++) {
            if (i % 2 == 0) {
                arr[i] = arr[i] * 2;
            } else {
                arr[i] = arr[i] * 3;
            }
        }
        System.out.println("Array after the changes: " + Arrays.toString(arr));
        
        
        
        System.out.println("Enter the value of n:");
         n = sc.nextInt();
        int[] arr1 = new int[n];
        
         for(int i=0;i<n;i++)
         {
             System.out.println("Enter arr1["+i+"]:");
             arr1[i]=sc.nextInt();
         }
         System.out.println("Array: "+Arrays.toString(arr1));
         
         for(int i=0;i<n;i++){
             if (i % 2 == 0) {
                arr1[i] = arr1[i] * 2;
            } else {
                arr1[i] = arr1[i] * 3;
            }
         }
      
      System.out.println("Array after the changes: " + Arrays.toString(arr1));
         }
    
  }

